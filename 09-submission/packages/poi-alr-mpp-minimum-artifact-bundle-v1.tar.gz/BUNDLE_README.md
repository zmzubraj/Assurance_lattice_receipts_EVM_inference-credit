# PoI ALR MPP minimum artifact bundle

Status: DEVELOPMENT DRAFT — NOT SUBMISSION READY and not authorized for public release.

This local-review bundle preserves the narrowed prototype, frozen development data,
negative and unresolved findings, analysis outputs, manuscript sources, compiled
draft PDFs, official-venue adaptation, reproducibility harness, and external human
and scientific gate instructions. File hashes are listed in BUNDLE_MANIFEST.csv.

Start with INDEX.md, 00-governance/EXTERNAL_HUMAN_SCIENTIFIC_GATE_RUNBOOK.md,
08-validation/EXTERNAL_REVIEW_PACKET.md,
08-validation/external-gate-kit/README.md, and artifact-registry.csv. The canonical
case remains at phase INTAKE. A clean build or matching hash does not establish
novelty, scientific validity, independent reproduction, authorship, licensing,
publication readiness, or submission authorization.

Frontiers draft build:
  cd 09-submission/frontiers-in-blockchain-technology-code
  ./build_frontiers_draft.sh

Fresh-directory reproduction candidate:
  python3 implementation/python/external_reproduction_candidate.py     --case-root . --output-dir /ABSOLUTE/REVIEWER_CONTROLLED/OUTPUT

Exact hermetic replay after the content-addressed runtime image is available:
  python3 09-submission/hermetic-runtime/run_external_hermetic_replay.py     --case-root /ABSOLUTE/PATH/TO/EXTRACTED/CASE     --output-dir /ABSOLUTE/REVIEWER_CONTROLLED/HERMETIC_OUTPUT
