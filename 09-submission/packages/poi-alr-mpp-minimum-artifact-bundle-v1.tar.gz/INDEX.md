# PoI-ALR-MPP

Run ID: `poi-alr-mpp-20260829T044029Z-b4e6442a-cd74f3`  
This is an evidence-gated research system. File existence, polished prose, or an AI score does not imply verification.

Authoritative control files: `program-state.json`, `artifact-registry.csv`, `orchestration-plan.json`, and the governance ledgers.
